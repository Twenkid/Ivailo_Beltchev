//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by boomd3d.rc
//
#define IDD_SELECT                      101
#define IDC_DRIVER                      1000
#define IDC_DEVICE                      1001
#define IDC_MODE                        1002
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

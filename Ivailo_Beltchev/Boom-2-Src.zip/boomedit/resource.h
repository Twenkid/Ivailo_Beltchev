//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by boomedit.rc
//
#define IDR_BOOMEDITACCEL               101
#define IDR_BOOMEDITMENU                102
#define IDD_ABOUT                       110
#define IDD_SECTORINFO                  111
#define IDD_CLUSTERS                    112
#define IDD_SECTOR                      113
#define IDD_NEWSECTOR                   114
#define IDR_FILETOOLBAR                 119
#define IDR_VIEWTOOLBAR                 120
#define IDR_EDITTOOLBAR                 121
#define IDB_BOOMBITMAP                  122
#define IDI_BOOMICON                    123
#define IDD_TEXTURES                    124
#define IDD_CHANGETEXTURE               125
#define IDD_MAPPING                     126
#define IDR_TOOLMENU                    127
#define IDC_EDITNAME                    1000
#define IDC_EDITZFA                     1001
#define IDC_EDITZFB                     1002
#define IDC_EDITZFC                     1003
#define IDC_EDITZCA                     1004
#define IDC_EDITZCB                     1005
#define IDC_EDITZCC                     1006
#define IDC_EDITLINES                   1007
#define IDC_CLUSTERS                    1008
#define IDC_CLUSTER                     1016
#define IDC_EDITCLUSTER                 1020
#define IDC_NEWCLUSTER                  1023
#define IDC_EDITFLOOR                   1025
#define IDC_EDITCEILING                 1027
#define IDC_ADDTXT                      1029
#define IDC_DELTXT                      1030
#define IDC_TXTBITMAP                   1031
#define IDC_TXTSCROLL                   1032
#define IDC_REPLACETXT                  1033
#define IDC_TXTSIZE                     1037
#define IDC_TXTNAME                     1038
#define IDC_MAP                         1040
#define IDC_POLYGONS                    1042
#define IDC_SAVETXT                     1043
#define ID_ZOOMIN                       40001
#define ID_ZOOMOUT                      40002
#define ID_FILEOPEN                     40003
#define ID_FILESAVE                     40004
#define ID_FILESAVEAS                   40005
#define ID_FILEEXIT                     40006
#define ID_ZOOMGRIDIN                   40010
#define ID_ZOOMGRIDOUT                  40011
#define ID_TOGGLEXY                     40012
#define ID_TOGGLEXZ                     40013
#define ID_TOGGLEYZ                     40016
#define ID_TOGGLE3D                     40017
#define ID_NEWCONTOUR                   40019
#define ID_NEWCLUSTER                   40020
#define ID_FILENEW                      40021
#define ID_NEWVERTEX                    40022
#define ID_TOGGLEGRID                   40023
#define ID_ABOUT                        40025
#define ID_JOINSECTORS                  40037
#define ID_INSERTSECTOR                 40038
#define ID_VIEWSECTOR                   40041
#define ID_VIEWCLUSTERS                 40042
#define ID_SECTOREDIT                   40044
#define ID_EDITSTARTPOINT               40046
#define ID_VIEWSTARTPOINT               40047
#define ID_EDITCURRENTPOINT             40049
#define ID_BUTTON40051                  40051
#define ID_BUTTON40052                  40052
#define ID_BUTTON40053                  40053
#define ID_BUTTON40054                  40054
#define ID_BUTTON40055                  40055
#define ID_BUTTON40060                  40060
#define ID_BUTTON40061                  40061
#define ID_BUTTON40073                  40073
#define ID_BUTTON40074                  40074
#define ID_BUTTON40075                  40075
#define ID_BUTTON40076                  40076
#define ID_BUTTON40077                  40077
#define ID_BUTTON40078                  40078
#define ID_BUTTON40079                  40079
#define ID_BUTTON40080                  40080
#define ID_BUTTON40081                  40081
#define ID_BUTTON40082                  40082
#define ID_BUTTON40083                  40083
#define ID_BUTTON40084                  40084
#define ID_BUTTON40085                  40085
#define ID_VIEWSTATUSBAR                40087
#define ID_FILETOOLBAR                  40090
#define ID_VIEWTOOLBAR                  40091
#define ID_EDITTOOLBAR                  40092
#define ID_DELETESECTOR                 40093
#define ID_VIEWCURRENTPOINT             40094
#define ID_GOTOCURRENTPOSITION          40095
#define ID_BUTTON40097                  40097
#define ID_TEXTURES                     40098
#define ID_PALETTE                      40100
#define ID_VIEWTEXTURES                 40101
#define ID_BUTTON40103                  40103
#define ID_BUTTON40104                  40104
#define ID_SETDEFFLOOR                  40105
#define ID_SETDEFCEILING                40106
#define ID_SETDEFWALL                   40107

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        128
#define _APS_NEXT_COMMAND_VALUE         40108
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

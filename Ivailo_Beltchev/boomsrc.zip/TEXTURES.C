//  ____________________________________
// |                                    |
// |  Project:  BOOM                    |
// |  File:     TEXTURES.C              |
// |  Target:   DOS4G/W                 |
// |  Compiler: Watcom C 10.6           |
// |                                    |
// |  Purpose:  TEXTURES MANAGEMENT     |
// |                                    |
// |  Authors:  Ivaylo Beltchev         |
// |            Emil Dotchevski         |
// |____________________________________|

// URL:      http://www.geocities.com/SiliconValley/Bay/3577/boom.html
// E-mail:   zajo@geocities.com


#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#define _DECLARE_TEXTURES_H
#include "TEXTURES.H"
#undef  _DECLARE_TEXTURES_H

/*
BITMAP SUPPORT
*/

  typedef struct
  {
    word  bfType;
    dword bfSize;
    word  bfReserved1;
    word  bfReserved2;
    dword bfOffBits;
  } tagBITMAPFILEHEADER;

  typedef struct
  {
    dword biSize;
    dword biWidth;
    dword biHeight;
    word  biPlanes;
    word  biBitCount;
    dword biCompression;
    dword biSizeImage;
    dword biXPelsPerMeter;
    dword biYPelsPerMeter;
    dword biClrUsed;
    dword biClrImportant;
  } tagBITMAPINFOHEADER;

  typedef struct
  {
    char rgbBlue;
    char rgbGreen;
    char rgbRed;
    char rgbReserved;
  } tagRGBQUAD;

  static int read_bmp_header( FILE *f, int *size_x, int *size_y )
  //1-OK, 0-read error, or unsupported bmp parameters
  //returns:
  //  size_x    - width of image in pixels
  //  size_y    - height of image in pixels
  {
    tagBITMAPFILEHEADER fh;
    tagBITMAPINFOHEADER fi;

    if( fseek( f, 0, SEEK_SET ) != 0                ||
        fread( &fh,   sizeof( fh   ),   1, f )!=  1 ||
        fread( &fi,   sizeof( fi   ),   1, f )!=  1 ||
        fseek( f, 256*4, SEEK_CUR )!=0              ||
        ferror( f )                                 ||
        fi.biBitCount!=8                            ||
        fi.biPlanes!=1                              ||
        fi.biCompression!=0 ) return 0;
    *size_x = fi.biWidth;
    *size_y = fi.biHeight;
    return 1;
  }

  int read_bmp( char *buffer, FILE *f, int size_x, int size_y )
  //1-OK, 0-read error
  {
    int ret, sx, i, lines_gap;

    ret = read_bmp_header( f, &size_x, &size_y );
    if( ret )
    {
      sx = size_x;
      while( sx%4 ) sx++;
      lines_gap = sx-size_x;
      buffer += (size_y-1) * size_x;
      for( i=0; i<size_y; i++ )
      {
        ret = ret && ( fread( buffer, size_x, 1, f )  ==1 );
        ret = ret && ( fseek( f, lines_gap, SEEK_CUR )==0 );
        buffer -= size_x;
      }
    }
    return ret && !ferror( f );
  }

struct Ttexture *new_texture( char *filename )
{
  int i, j;
  struct Ttexture *t;
  FILE *f=fopen( filename, "rb" );
  t=(struct Ttexture *)malloc( sizeof(*t) );
  read_bmp_header( f, &t->size_x, &t->size_y );
  _splitpath( filename, NULL, NULL, t->fname, NULL );
  t->bmp = (char*)malloc( t->size_x*t->size_y );
  read_bmp( t->bmp, f, t->size_x, t->size_y );
  fclose( f );
  for( i=0; i<t->size_y; i++ )
    for( j=i; j<t->size_x; j++ )
    {
      char c = t->bmp[i*t->size_x+j];
      t->bmp[i*t->size_x+j] = t->bmp[j*t->size_x+i];
      t->bmp[j*t->size_x+i] = c;
    }
  t->next = textures;
  textures = t;
  return t;
}

void get_textures( void )
{
  FILE *f;
  struct find_t dir_info;
  int done;
  char *fn = strchr( textures_path, 0 );

  strcpy( fn, "TEXTURES.PAL" );
  f = fopen( textures_path, "rb" );
  fread( palette, sizeof( Tpalette ), 256, f );
  fclose( f );

  strcpy( fn, "*.BMP" );
  done = _dos_findfirst( textures_path, _A_NORMAL, &dir_info );
  while( !done )
  {
    strcpy( fn, dir_info.name );
    new_texture( textures_path );
    done = _dos_findnext( &dir_info );
  }
  *fn = 0;
}

struct Ttexture *texture( char *name )
{
  struct Ttexture *i;
  if( *name==0 ) return NULL;
  *(strchr( name, 0 )-1)=0;
  for( i=textures; i!=NULL; i=i->next )
    if( stricmp( i->fname, name+1 )==0 ) return i;
  return NULL;
}

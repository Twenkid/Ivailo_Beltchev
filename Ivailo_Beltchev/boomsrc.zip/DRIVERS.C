//  ____________________________________
// |                                    |
// |  Project:  BOOM                    |
// |  File:     DRIVERS.C               |
// |  Target:   DOS4G/W                 |
// |  Compiler: Watcom C 10.6           |
// |                                    |
// |  Purpose:  SYSTEM DRIVERS          |
// |                                    |
// |  Authors:  Ivaylo Beltchev         |
// |            Emil Dotchevski         |
// |____________________________________|

// URL:      http://www.geocities.com/SiliconValley/Bay/3577/boom.html
// E-mail:   zajo@geocities.com


#define _DECLARE_DRIVERS_H
#include "DRIVERS.H"
#undef  _DECLARE_DRIVERS_H

/*
INCLUDES
*/
  #include <conio.h>
  #include <dos.h>
  #include <stdlib.h>
  #include "BASICS.H"


/*
PATCHES
*/
  extern void set_timer( int );
  #pragma aux set_timer =   \
    "cli"                   \
    "mov al,00110110b"      \
    "out 43h,al"            \
    "mov al,dl"             \
    "out 40h,al"            \
    "mov al,dh"             \
    "out 40h,al"            \
    "sti"                   \
    parm [edx]              \
    modify [eax edx];

  extern void cld( void );
  #pragma aux cld = "cld";

  extern void _loades( void );
  #pragma aux _loades =     \
    "mov ax,ds"             \
    "mov es,ax"             \
    modify [ax];

  extern void clear_intr( void );
  #pragma aux clear_intr =  \
    "mov al,20h"            \
    "out 20h,al"            \
    modify [al];


/*
CLI & STI
*/
  static cli_counter=0;

  static void cli( void )
  {
    if( !cli_counter++ ) _disable();
  }

  static void sti( void )
  {
    if( !--cli_counter ) _enable();
  }


/*
EVENTS DRIVER
*/
  static Tevent queue[MAX_EVENTS];
  static int qhead=0, qtail=0;

  int get_event( Tevent *ev )
  {
    if( qtail==qhead )
      ev->code=evNOTHING;
    else
    {
      int q;
      cli();
      q=qtail;
      if( ++qtail==MAX_EVENTS ) qtail=0;
      *ev = queue[q];
      sti();
    }
    return ev->code;
  }

  void put_event( Tevent *ev )
  {
    int q;
    cli();
    q=qhead+1;
    if( q==MAX_EVENTS ) q=0;
    if( q==qtail ) return;
    queue[qhead] = *ev;
    queue[qhead].time_stamp = timer;
    qhead=q;
    sti();
  }


/*
KEYBOARD INTERRUPTS HANDLING
*/
  //Dummy function to indicate org of the code to lock
  static void kbd_lock_region_begin( void )
  {
  }

  static Tevent ev;
  static void _loadds interrupt keyboard_handler( void )
  {
    static boolean ext_key = 0;
    static char old_key = 0;
    unsigned short *bios_qh = (unsigned short *) BIOS_DTA( 0x1C );
    unsigned short *bios_qt = (unsigned short *) BIOS_DTA( 0x1A );
    char k;

    cli();
    cld();
    _loades();
    k = (char) inp( 0x60 );
    OLD_KEYBOARD_HANDLER();
    *bios_qt = *bios_qh;
    if( k==0xE0 )
    {
      ext_key=1;
      return;
    }
    if( old_key==k ) return;
    old_key = k;
    ev.code = evKEY_DOWN;
    if( k&0x80 ) ev.code = evKEY_UP;
    k &= 0x7F;
    if( k>=2 && k<=11 )
    {
      key_clust = k-2;
      return;
    }
    ev.SCAN_CODE = k;
    ev.EXT_KEY = ext_key;
    ext_key = 0;
    put_event( &ev );
    sti();
  }

  //Dummy function to indicate end of the code to lock
  void kbd_lock_region_end( void )
  {
  }


/*
TIMER INTERRUPTS HANDLING
*/
  //Dummy function to indicate org of the code to lock
  void timer_lock_region_begin( void )
  {
  }

  static void _loadds interrupt timer_handler( void )
  {
    static int counter=1;
    cld();
    _loades();
    timer++;
    if( --counter )
      clear_intr();
    else
    {
      counter=8;
      OLD_TIMER_HANDLER();
    }
  }

  //Dummy function to indicate end of the code to lock
  void timer_lock_region_end( void )
  {
  }


/*
INITIALIZATION
*/
  int lock_region( void *address, unsigned length )
  {
    union REGS regs;
    unsigned linear;

    linear = (unsigned) address;
    regs.w.ax = 0x600;
    regs.w.bx = (unsigned short) ( linear >> 16 );
    regs.w.cx = (unsigned short) ( linear & 0xFFFF );
    regs.w.si = (unsigned short) ( length >> 16 );
    regs.w.di = (unsigned short) ( length & 0xFFFF );
    int386( 0x31, &regs, &regs );
    return !regs.w.cflag; //return 0 if can't lock
  }

  static void tini_kbd( void )
  {
    _dos_setvect( KBD_INTR, OLD_KEYBOARD_HANDLER );
  }

  void init_kbd( void )
  {
    lock_region( &kbd_data, sizeof( kbd_data ) );
    lock_region( ( void near * ) kbd_lock_region_begin,
                   ( char * ) kbd_lock_region_end -
                   ( char * ) kbd_lock_region_begin );
    OLD_KEYBOARD_HANDLER = _dos_getvect( KBD_INTR );
    _dos_setvect( KBD_INTR, keyboard_handler );
    atexit( tini_kbd );
  }

  void tini_timer( void )
  {
    set_timer( 0 );
    _dos_setvect( TIMER_INTR, OLD_TIMER_HANDLER );
  }

  void init_timer( void )
  {
    lock_region( &timer_data, sizeof( timer_data ) );
    lock_region( (void near *) timer_lock_region_begin,
                   (char *) timer_lock_region_end -
                   (char *) timer_lock_region_begin );
    OLD_TIMER_HANDLER = _dos_getvect( TIMER_INTR );
    _dos_setvect( TIMER_INTR, timer_handler );
    set_timer( 8192 ); //aprox. 146 ticks/second
    atexit( tini_timer );
  }

//  ____________________________________
// |                                    |
// |  Project:  BOOM                    |
// |  File:     SCREEN.C                |
// |  Target:   DOS4G/W                 |
// |  Compiler: Watcom C 10.6           |
// |                                    |
// |  Purpose:  SCREEN SUPPORT          |
// |                                    |
// |  Authors:  Ivaylo Beltchev         |
// |            Emil Dotchevski         |
// |____________________________________|

// URL:      http://www.geocities.com/SiliconValley/Bay/3577/boom.html
// E-mail:   zajo@geocities.com


#define _DECLARE_SCREEN_H
#include "SCREEN.H"
#undef  _DECLARE_SCREEN_H


/*
INCLUDES
*/
#include <conio.h>
#include <i86.h>
#include <stdarg.h>
#include <stdio.h>
#include "GRTEXT.H"
#include "TEXTURES.H"


/*
INIT_SCREEN( int mode, char *pal_name )
*/
  void set_metrics( int cols, int rows, int dx )
  {
    int i,j;

    for( i=0,j=0; i<MAX_SCR_ROWS; i++,j+=dx )
      scr_table[i] = j;
    scr_cols = cols;
    scr_rows = rows;
    scr_dx   = dx;
    scr_ox   = cols/2;
    scr_oy   = rows/2;
    scr_foc  = cols/2;
    scr_min  = cols*8;
    scr_len  = cols/4;
  }


  static void set_video_mode( int mode )
  //set graphics video mode
  {
    union REGS r;
//    struct SREGS s;
//    char svgabuf[256];

    switch( mode )
    {
      case vm320x200:
        r.x.eax = 0x13;
        int386( 0x10, &r, &r );
        set_metrics( 320, 200, 320 );
        break;
      case vm640x480:
/*
        segread( &s );
        r.x.edi = FP_OFF( svgabuf );
        s.es    = FP_SEG( svgabuf );
        r.x.eax = 0x4F00;
        int386x( 0x10, &r, &r, &s );
*/
        svga_gran = 1;
        r.x.eax  = 0x4F02;
        r.x.ebx  = 0x101;
        int386( 0x10, &r, &r );
        r.x.eax = 3;
        int386( 0x10, &r, &r );
        r.x.eax = 0x4F02;
        r.x.ebx = 0x101;
        int386( 0x10, &r, &r );
        set_metrics( 640, 480, 640 );
        break;
    }
  }


  static void set_palette( void )
  {
    int i;

    outp( 0x3C6, 0xFF );
    for( i = 0; i < 256; i++ )
    {
      outp( 0x3C8, i );
      outp( 0x3C9, palette[i].r );
      outp( 0x3C9, palette[i].g );
      outp( 0x3C9, palette[i].b );
    }
  }


  void init_screen( int mode )
  {
    set_video_mode( mode );
    set_palette();
  }


void done_screen( void )
//set video mode 3
{
  union REGS r;

  r.x.eax = 3;
  int386( 0x10, &r, &r );
}


void set_screen_size( int cols, int rows )
{
  set_metrics( cols, rows, scr_dx );
}

void txt( int x, int y, int color, char *t, ... )
{
  va_list argptr;
  char buffer[256];

  va_start( argptr, t );
  vsprintf( buffer, t, argptr );
  va_end( argptr );
  out_str( x, y, color, buffer );
}

//  ____________________________________
// |                                    |
// |  Project:  BOOM                    |
// |  File:     CMDLINE.C               |
// |  Target:   DOS4G/W                 |
// |  Compiler: Watcom C 10.6           |
// |                                    |
// |  Purpose:  COMMAND LINE PARSER     |
// |                                    |
// |  Authors:  Ivaylo Beltchev         |
// |            Emil Dotchevski         |
// |____________________________________|

// URL:      http://www.geocities.com/SiliconValley/Bay/3577/boom.html
// E-mail:   zajo@geocities.com


#define _DECLARE_CMDLINE_H
#include "CMDLINE.H"
#undef  _DECLARE_CMDLINE_H

/*
INCLUDES
*/
#include <stdlib.h>
#include <string.h>


static const char *argv;

int param_kind( const char *p )
{
  argv = p;
  strupr( argv );
  if( *argv=='/' || *argv=='-' )
    if( strchr( argv, ':' )==NULL )
      return pkSWITCH;
    else
      return pkPARAM;
  else
    return pkFILE;
}

int check_switch( char *sw )
{
  strupr( sw );
  return ( strcmp( argv, sw )==0 );
}

char *check_param_str( char *buf, char *pr )
{
  char *c;
  int fl;

  strupr( pr );
  c = strchr( argv, ':' );
  *c = 0;
  fl = strcmp( argv, pr );
  *c = ':';
  if( fl!=0 ) return NULL;
  strcpy( buf, c+1 );
  return buf;
}

int check_param_int( char *pr )
{
  char buf[128];

  if( check_param_str( buf, pr )==NULL ) return 0;
  return atoi( buf );
}

char *add_ext( char *path, char *ext )
{
  char drive[_MAX_DRIVE];
  char dir[_MAX_DIR];
  char fname[_MAX_FNAME];
  char xt[_MAX_EXT];

  _splitpath( path, drive, dir, fname, xt );
  if( *xt == 0 ) strcpy( xt, ext );
  _makepath( path, drive, dir, fname, xt );
  return path;
}
